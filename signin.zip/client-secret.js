import { createHmac } from 'crypto';

export const getAwsSecretHash = (email) => {
  const CLIENT_SECRET = "1e4940osjmc32ku4fnhe9lqg8up4md8fstqr1gm7iu45n88717lr";
  const CLIENT_ID = "70tm6t13cki7t3lskg9700p79h";

  const hasher = createHmac('sha256', CLIENT_SECRET);
  hasher.update(`${email}${CLIENT_ID}`);
  const secretHash = hasher.digest('base64');

  return secretHash;
}